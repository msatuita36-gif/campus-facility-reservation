from pathlib import Path
from datetime import datetime
import json
import joblib
import pandas as pd
import streamlit as st
import plotly.express as px

from modules.data_processing import clean_dataset, validate_dataset, REQUIRED_COLUMNS
from modules.exploratory_analysis import render_analysis
from modules.prediction import predict_one, sample_predictions
from modules.dashboard import render_dashboard

ROOT = Path(__file__).parent
st.set_page_config(page_title="Campus Facility Reservation Monitoring", page_icon="🏫", layout="wide")

@st.cache_resource
def load_model():
    return joblib.load(ROOT / "models" / "trained_model.joblib")

@st.cache_data
def load_default_data():
    path = ROOT / "data" / "facility_reservations_cleaned.csv"
    return pd.read_csv(path)

artifact = load_model()
model = artifact["pipeline"]
features = artifact["features"]
df_default = load_default_data()

st.sidebar.title("🏫 Facility Monitor")
st.sidebar.caption("SAD Data Mining • Streamlit deployment")
page = st.sidebar.selectbox("Navigate", ["Home", "Dataset", "Data Analysis", "Prediction", "Dashboard", "System Design"])
st.sidebar.divider()
st.sidebar.caption("Model v1.0 • Decision support only")

if "active_data" not in st.session_state:
    st.session_state.active_data = df_default.copy()

df = st.session_state.active_data.copy()

if page == "Home":
    st.title("Campus Facility Reservation Monitoring System")
    st.write("A Streamlit decision-support application for reviewing facility reservation patterns and estimating whether a reservation may be completed.")
    c1,c2,c3 = st.columns(3)
    c1.metric("Reservations loaded", f"{len(df):,}")
    c2.metric("Facilities represented", int(df["Facility_Type"].nunique()) if "Facility_Type" in df else 0)
    c3.metric("Model test accuracy", f'{artifact["metrics"]["accuracy"]:.1%}')
    st.info("Predictions are advisory. An authorized facility administrator must review context and make the final decision.")
    st.subheader("Available modules")
    st.markdown("- **Dataset:** upload and validate a CSV, preview records, and inspect missing values and duplicates.\n- **Data Analysis:** interactive charts and descriptive statistics.\n- **Prediction:** enter booking-time details and obtain a model estimate.\n- **Dashboard:** observed KPIs and a human-review queue.\n- **System Design:** functional requirements, actors, use-case diagram, and decision workflow.")
    st.subheader("Dataset preview")
    st.dataframe(df.head(8), use_container_width=True)

elif page == "Dataset":
    st.title("Dataset Upload and Validation")
    st.write("Upload a CSV with the required reservation columns. If no file is uploaded, the included cleaned dataset is used.")
    uploaded = st.file_uploader("Upload reservation dataset (.csv)", type=["csv"])
    if uploaded is not None:
        try:
            uploaded_df = pd.read_csv(uploaded)
            ok, missing = validate_dataset(uploaded_df)
            if not ok:
                st.error("Missing required columns: " + ", ".join(missing))
                st.caption("The previous active dataset remains loaded.")
            elif uploaded_df.empty:
                st.error("The uploaded CSV has no data rows.")
            else:
                cleaned = clean_dataset(uploaded_df)
                st.session_state.active_data = cleaned
                df = cleaned
                st.success(f"Validated and loaded {len(cleaned)} rows.")
        except Exception as exc:
            st.error(f"Could not read this CSV: {exc}")
    ok, missing = validate_dataset(df)
    if ok:
        st.success("Required schema is present.")
    else:
        st.error("Dataset schema is incomplete: " + ", ".join(missing))
    a,b,c = st.columns(3)
    a.metric("Rows", len(df))
    b.metric("Columns", len(df.columns))
    c.metric("Exact duplicate rows", int(df.duplicated().sum()))
    st.subheader("Data preview")
    st.dataframe(df.head(30), use_container_width=True)
    st.subheader("Missing values by column")
    miss = df.isna().sum().rename("Missing values").reset_index(names="Column")
    st.dataframe(miss, use_container_width=True)
    st.download_button("Download active cleaned CSV", df.to_csv(index=False).encode("utf-8"), "facility_reservations_cleaned.csv", "text/csv")

elif page == "Data Analysis":
    st.title("Exploratory Data Analysis")
    render_analysis(df)

elif page == "Prediction":
    st.title("Reservation Outcome Prediction")
    st.write("Enter details available when the reservation is submitted. Post-outcome fields such as actual attendance and cancellation timing are not used.")
    with st.form("prediction_form"):
        c1,c2,c3 = st.columns(3)
        facility = c1.selectbox("Facility type", sorted(df["Facility_Type"].dropna().astype(str).unique()))
        user_category = c2.selectbox("User category", sorted(df["User_Category"].dropna().astype(str).unique()) if df["User_Category"].notna().any() else ["Unknown"])
        purpose = c3.selectbox("Reservation purpose", sorted(df["Reservation_Purpose"].dropna().astype(str).unique()))
        c4,c5,c6 = st.columns(3)
        lead = c4.number_input("Lead time (days)", min_value=0, max_value=365, value=7)
        participants = c5.number_input("Participants", min_value=1, max_value=10000, value=30)
        capacity = c6.number_input("Facility capacity", min_value=1, max_value=10000, value=50)
        c7,c8,c9 = st.columns(3)
        duration = c7.number_input("Duration (hours)", min_value=1, max_value=24, value=2)
        weekday = c8.selectbox("Reservation weekday (0=Mon … 6=Sun)", list(range(7)), index=2)
        start_hour = c9.slider("Start hour (24-hour clock)", 0, 23, 10)
        submitted = st.form_submit_button("Predict outcome", type="primary")
    if submitted:
        record = {"Facility_Type":facility,"User_Category":user_category,"Reservation_Purpose":purpose,"Lead_Time_Days":lead,"Participants":participants,"Facility_Capacity":capacity,"Duration_Hours":duration,"Reservation_Weekday":weekday,"Start_Hour":start_hour}
        try:
            pred, probability = predict_one(model, features, record)
            st.subheader("Prediction result")
            if pred == "Completed":
                st.success(f"Model estimate: {pred}")
            else:
                st.warning(f"Model estimate: {pred} — review recommended")
            st.write(f"Estimated probability for the predicted class: **{probability:.1%}**")
            st.caption("This probability is a model estimate, not a guarantee. Do not automatically reject a reservation based on this result.")
            st.write("**Suggested human follow-up:** verify booking details and contact the requester for confirmation if needed.")
            st.code(json.dumps({"prediction":pred,"predicted_class_probability":round(probability,4),"model_version":artifact["model_version"],"prediction_timestamp":datetime.now().isoformat(timespec="seconds")},indent=2))
        except Exception as exc:
            st.error(f"Prediction could not be completed: {exc}")
    st.subheader("Five sample predictions")
    sample = sample_predictions(model, features, df)
    st.dataframe(sample, use_container_width=True)

elif page == "Dashboard":
    st.title("Decision-Support Dashboard")
    render_dashboard(df, artifact, model, features)

elif page == "System Design":
    st.title("System Design and SAD Integration")
    st.subheader("Actors")
    st.markdown("- **Facility Administrator:** reviews reservation risk, checks records, and records the final decision.\n- **Requester / Student / Staff:** provides reservation details and may be contacted for confirmation.\n- **System Administrator:** maintains the application, dataset, and model files.")
    st.subheader("Five functional requirements")
    st.markdown("1. The system shall accept CSV uploads and validate required columns.\n2. The system shall display dataset previews, missing-value counts, and duplicate summaries.\n3. The system shall display descriptive statistics and interactive reservation charts.\n4. The system shall estimate reservation outcomes using the saved trained pipeline and show model evaluation metrics.\n5. The system shall present observed KPIs and a review queue to support authorized human decisions.")
    st.subheader("Three non-functional requirements")
    st.markdown("1. **Usability:** navigation and outputs must be understandable to a facility administrator.\n2. **Reliability:** invalid files and unexpected inputs must produce clear error messages rather than silently failing.\n3. **Privacy and security:** only synthetic or properly authorized data should be deployed publicly; secrets and sensitive records must not be committed to GitHub.")
    st.subheader("Use case diagram")
    st.image(str(ROOT / "assets" / "use_case_diagram.png"), use_container_width=True)
    st.subheader("Decision-support workflow")
    st.image(str(ROOT / "assets" / "decision_workflow.png"), use_container_width=True)
    st.caption("The model supports review; it does not automatically approve or reject reservations.")
