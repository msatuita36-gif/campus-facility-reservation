# Short Deployment Report

## 1. Reused midterm work
The original midterm notebook (`midterm_original.ipynb`) is included unchanged. The revised project reuses its problem definition, reservation-outcome target, decision-tree approach, 80/20 train/test split, fixed random seed, model metrics, exploratory-analysis questions, and leakage-avoidance principle.

## 2. Changes made for Streamlit
- Converted notebook-style outputs into a multi-page Streamlit app with Home, Dataset, Data Analysis, Prediction, Dashboard, and System Design modules.
- Added CSV upload and required-column validation, data preview, missing-value counts, duplicate summary, and cleaned CSV download.
- Added interactive Plotly charts and descriptive statistics.
- Saved the preprocessing + Decision Tree pipeline to `models/trained_model.joblib`; the app loads it using a cached resource instead of retraining on every page refresh.
- Added a prediction form using fields available when a reservation is submitted, five sample predictions, model metrics, a review queue, system requirements, a use-case diagram, and decision workflow.

## 3. Dataset reconciliation
The supplied Excel dataset contains 365 rows and 13 columns. After cleaning and removing duplicate reservation IDs, the cleaned dataset contains 360 rows. The Excel schema differs from some names in the original notebook. The app uses the actual provided schema and uses `Reservation_Purpose`, `Reservation_Weekday`, `Start_Hour`, and `Facility_Capacity` where applicable rather than assuming `Reservation_Method` exists.

## 4. Tests performed
- Checked that the provided workbook can be read and the required reservation columns exist.
- Cleaned and exported the dataset; standardized category text, handled missing booking-time numeric values, mapped the target, and removed duplicate reservation IDs.
- Trained and saved the pipeline with a stratified 80/20 split and `random_state=42`.
- Tested model prediction on a single row and five sample records.
- Checked Python source files for syntax errors.
- Added clear errors for invalid CSV schema and warnings that predictions require human review.

## 5. Results
Held-out test metrics from this run:
- Accuracy: 0.653
- Weighted precision: 0.650
- Weighted recall: 0.653
- Weighted F1-score: 0.651

These metrics are dataset-specific and do not guarantee performance on future reservations.

## 6. Limitations
The supplied dataset appears to be a classroom/laboratory dataset and may not represent future real-world reservations. The target is derived from recorded `Usage_Status`. Some columns are absent from the Excel file despite being mentioned in the notebook. Model estimates may be biased by data quality, sample size, and patterns in the sample. The app does not authenticate individual users or persist administrator decisions to a database.

## 7. Reflection
This deployment demonstrates how a notebook-based data-mining workflow can become an interactive decision-support application. The most important implementation choices were keeping the saved pipeline consistent with the training features, validating uploads, excluding post-outcome leakage fields, showing evaluation metrics, and leaving the final reservation decision to an authorized person.
