# GitHub Upload Checklist

1. Create a public repository named `campus-facility-reservation`.
2. Upload the contents of this ZIP while preserving all folders.
3. Confirm `app.py`, `requirements.txt`, `models/trained_model.joblib`, `modules/`, `data/`, and `assets/` are in the repository root structure.
4. Open https://share.streamlit.io and sign in with GitHub.
5. Create an app using branch `main` and main file path `app.py`.
6. Deploy and save the GitHub repository URL and Streamlit URL for submission.
7. Capture real screenshots after running/deploying the app. The `screenshots/` folder contains preview images to guide the screenshots required by the rubric.
