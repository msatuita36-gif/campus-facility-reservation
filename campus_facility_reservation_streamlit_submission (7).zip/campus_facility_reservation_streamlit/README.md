# Campus Facility Reservation Monitoring System (Streamlit)

A Streamlit decision-support app based on the provided midterm notebook and `facility_reservations (1).xlsx` dataset.

## Run locally
1. Install Python 3.10+.
2. Unzip the project.
3. Open a terminal in this folder.
4. Run `pip install -r requirements.txt`.
5. Run `streamlit run app.py`.

## App modules
- Home
- Dataset upload and validation
- Data Analysis (interactive Plotly charts)
- Prediction (booking-time fields only)
- Dashboard (observed KPIs, model metrics, human-review queue)
- System Design (requirements, use case diagram, decision workflow)

## Dataset and model notes
The uploaded Excel file contains 365 rows and 13 columns. The app's cleaned dataset standardizes categories, fills missing booking-time numeric values, maps `Used` to `Completed`, and maps `Cancelled`/`No-Show` to `Not Completed`. Duplicate reservation IDs are removed, leaving 360 rows in the cleaned export.

The provided notebook and dataset use some different feature names. The notebook mentions `Reservation_Method` and `Lead_Time_Category` as predictors in parts, but the provided Excel file contains `Reservation_Purpose`, `Reservation_Weekday`, `Start_Hour`, and `Facility_Capacity`. The revised Streamlit model was trained using columns actually present in the supplied Excel dataset: `Facility_Type`, `User_Category`, `Reservation_Purpose`, `Lead_Time_Days`, `Participants`, `Facility_Capacity`, `Duration_Hours`, `Reservation_Weekday`, and `Start_Hour`.

Target: `Reservation_Outcome` (`Completed` for `Used`; `Not Completed` for `Cancelled` or `No-Show`).

Post-outcome leakage fields are excluded from prediction: `Usage_Status`, `Actual_Attendance`, `Cancellation_Days_Before`, and `Attendance_Ratio`.

## Model
A scikit-learn preprocessing + Decision Tree pipeline is saved at `models/trained_model.joblib`. It uses an 80/20 stratified split and `random_state=42`. The reported held-out metrics are in `models/metrics.json`; they are for this supplied dataset and are not a guarantee of future performance.

## Deploy to Streamlit Community Cloud
1. Create a GitHub repository and upload the project files (preserve folder structure).
2. Open https://share.streamlit.io and sign in with GitHub.
3. Create an app, select your repository and `main` branch, set `app.py` as the main file, then deploy.
4. If deployment fails, inspect the build logs and confirm `requirements.txt` and model path.

## Important limitation
Predictions are decision-support outputs, not automatic authorization to reject a reservation or deny student services. Use synthetic or properly authorized data for public deployment. Never commit secrets or sensitive student records.
