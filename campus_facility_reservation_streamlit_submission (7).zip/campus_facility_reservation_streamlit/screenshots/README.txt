SCREENSHOT NOTE

The PNG files in this folder are labeled preview mockups to show the intended layout of the six Streamlit modules. They are not captured from a live running Streamlit session. For the assignment's screenshot requirement, run/deploy the app and replace/add real screenshots showing:
1. Home
2. Dataset upload and validation
3. Data Analysis with charts
4. Prediction page and result
5. Dashboard
Also capture five sample prediction rows (a table export is included in data/five_sample_predictions.csv).
