import streamlit as st
import pandas as pd
import plotly.express as px

def render_analysis(df):
    if df.empty:
        st.warning("No rows to analyze.")
        return
    st.subheader("Descriptive statistics")
    st.dataframe(df.describe(include="all").transpose(), use_container_width=True)
    c1,c2 = st.columns(2)
    with c1:
        counts = df["Facility_Type"].astype(str).value_counts().rename_axis("Facility Type").reset_index(name="Reservations")
        fig = px.bar(counts, x="Facility Type", y="Reservations", title="Reservations by Facility Type")
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        if "Reservation_Outcome" not in df.columns and "Usage_Status" in df.columns:
            status_map = {"Used":"Completed","Cancelled":"Not Completed","No-Show":"Not Completed","Canceled":"Not Completed"}
            df = df.copy()
            df["Reservation_Outcome"] = df["Usage_Status"].map(status_map)
        outcome = df["Reservation_Outcome"].fillna("Unknown").value_counts().rename_axis("Outcome").reset_index(name="Count")
        fig = px.pie(outcome, names="Outcome", values="Count", title="Reservation Outcome Distribution")
        st.plotly_chart(fig, use_container_width=True)
    c3,c4 = st.columns(2)
    with c3:
        d = df.copy()
        status_map = {"Used":"Completed","Cancelled":"Not Completed","No-Show":"Not Completed","Canceled":"Not Completed"}
        if "Reservation_Outcome" not in d.columns:
            d["Reservation_Outcome"] = d["Usage_Status"].map(status_map)
        rate = d.assign(NotCompleted=d["Reservation_Outcome"].eq("Not Completed")).groupby("User_Category", dropna=False)["NotCompleted"].mean().mul(100).reset_index(name="Not completed (%)")
        fig = px.bar(rate, x="User_Category", y="Not completed (%)", title="Not-completed rate by user category")
        st.plotly_chart(fig, use_container_width=True)
    with c4:
        if "Lead_Time_Days" in df.columns:
            d = df.copy()
            d["Lead-time category"] = pd.cut(d["Lead_Time_Days"], [-1,2,7,14,float("inf")], labels=["Last Minute","Short Lead","Medium Lead","Early Booking"])
            status = d.assign(NotCompleted=d["Reservation_Outcome"].eq("Not Completed")).groupby("Lead-time category", observed=False)["NotCompleted"].mean().mul(100).reset_index(name="Not completed (%)")
            fig = px.bar(status, x="Lead-time category", y="Not completed (%)", title="Not-completed rate by lead time")
            st.plotly_chart(fig, use_container_width=True)
    st.caption("Percentages use the reservations in each displayed group as the denominator. Charts show observed data, not predictions.")
