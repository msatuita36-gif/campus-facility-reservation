import pandas as pd
import numpy as np

REQUIRED_COLUMNS = [
    "Reservation_ID", "Facility_Type", "User_Category", "Reservation_Purpose",
    "Lead_Time_Days", "Participants", "Facility_Capacity", "Duration_Hours",
    "Reservation_Weekday", "Start_Hour", "Usage_Status"
]

def validate_dataset(df):
    if not isinstance(df, pd.DataFrame):
        return False, REQUIRED_COLUMNS
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    return len(missing) == 0, missing

def clean_dataset(df):
    out = df.copy()
    out.columns = out.columns.astype(str).str.strip()
    ok, missing = validate_dataset(out)
    if not ok:
        raise ValueError("Missing required columns: " + ", ".join(missing))
    for col in ["Facility_Type", "User_Category", "Reservation_Purpose"]:
        out[col] = out[col].astype("string").str.strip()
        out[col] = out[col].replace("", pd.NA)
    out["Facility_Type"] = out["Facility_Type"].fillna("Unknown").str.title()
    out["User_Category"] = out["User_Category"].fillna("Unknown")
    out["Reservation_Purpose"] = out["Reservation_Purpose"].fillna("Unknown")
    numeric = ["Lead_Time_Days", "Participants", "Facility_Capacity", "Duration_Hours", "Reservation_Weekday", "Start_Hour"]
    for col in numeric:
        out[col] = pd.to_numeric(out[col], errors="coerce")
        if col == "Lead_Time_Days":
            out.loc[out[col] < 0, col] = np.nan
        median = out[col].median()
        out[col] = out[col].fillna(0 if pd.isna(median) else median)
    out["Lead_Time_Days"] = out["Lead_Time_Days"].round().astype(int)
    out["Usage_Status"] = out["Usage_Status"].astype("string").str.strip().str.title()
    out["Reservation_Outcome"] = out["Usage_Status"].map({
        "Used": "Completed", "Cancelled": "Not Completed", "Canceled": "Not Completed",
        "No-Show": "Not Completed", "Noshow": "Not Completed"
    })
    bins = [-1, 2, 7, 14, float("inf")]
    labels = ["Last Minute", "Short Lead", "Medium Lead", "Early Booking"]
    out["Lead_Time_Category"] = pd.cut(out["Lead_Time_Days"], bins=bins, labels=labels).astype("string")
    if "Actual_Attendance" in out.columns:
        attendance = pd.to_numeric(out["Actual_Attendance"], errors="coerce")
        out["Attendance_Ratio"] = np.where(out["Participants"] > 0, attendance / out["Participants"], np.nan)
    if "Reservation_ID" in out.columns:
        out = out.drop_duplicates(subset=["Reservation_ID"], keep="first")
    return out
