import pandas as pd

def predict_one(model, features, record):
    row = pd.DataFrame([{c: record.get(c) for c in features}], columns=features)
    pred = str(model.predict(row)[0])
    probability = 0.0
    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(row)[0]
        classes = list(model.classes_)
        if pred in classes:
            probability = float(probs[classes.index(pred)])
    return pred, probability

def sample_predictions(model, features, df, count=5):
    if df.empty:
        return pd.DataFrame()
    available = df.dropna(subset=[c for c in features if c in df.columns]).head(count).copy()
    if available.empty:
        return pd.DataFrame()
    preds = model.predict(available[features])
    result = available[[c for c in ["Reservation_ID","Facility_Type","User_Category","Lead_Time_Days","Participants"] if c in available.columns]].copy()
    result["Predicted Outcome"] = preds
    if "Reservation_Outcome" in available.columns:
        result["Observed Outcome"] = available["Reservation_Outcome"].values
    return result
