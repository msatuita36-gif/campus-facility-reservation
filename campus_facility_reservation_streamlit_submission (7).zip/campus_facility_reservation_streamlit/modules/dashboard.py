import streamlit as st
import pandas as pd
import plotly.express as px
from modules.prediction import sample_predictions

def render_dashboard(df, artifact, model, features):
    d = df.copy()
    if "Reservation_Outcome" not in d.columns:
        d["Reservation_Outcome"] = d["Usage_Status"].map({"Used":"Completed","Cancelled":"Not Completed","Canceled":"Not Completed","No-Show":"Not Completed"})
    total = len(d)
    completed = int(d["Reservation_Outcome"].eq("Completed").sum())
    not_completed = int(d["Reservation_Outcome"].eq("Not Completed").sum())
    known = int(d["Reservation_Outcome"].notna().sum())
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total reservations", f"{total:,}")
    c2.metric("Completed", f"{completed:,}")
    c3.metric("Cancelled / no-show", f"{not_completed:,}")
    c4.metric("Completion rate", f"{completed/known:.1%}" if known else "N/A")
    st.subheader("Model evaluation (held-out test set)")
    metrics = artifact["metrics"]
    a,b,c,e = st.columns(4)
    a.metric("Accuracy", f'{metrics["accuracy"]:.1%}')
    b.metric("Weighted precision", f'{metrics["precision_weighted"]:.1%}')
    c.metric("Weighted recall", f'{metrics["recall_weighted"]:.1%}')
    e.metric("Weighted F1", f'{metrics["f1_weighted"]:.1%}')
    st.subheader("Reservations for human review")
    st.caption("The sample queue below is illustrative and based on predictions; it is not an automatic rejection list.")
    samples = sample_predictions(model, features, d, count=10)
    if not samples.empty:
        review = samples[samples["Predicted Outcome"].eq("Not Completed")]
        st.dataframe(review if not review.empty else samples, use_container_width=True)
    st.subheader("Observed outcome mix")
    outcome = d["Reservation_Outcome"].fillna("Unknown").value_counts().rename_axis("Outcome").reset_index(name="Reservations")
    st.plotly_chart(px.bar(outcome, x="Outcome", y="Reservations", title="Observed reservation outcomes"), use_container_width=True)
    st.warning("Human review is required. Do not automatically deny access or reject a reservation based only on model output.")
